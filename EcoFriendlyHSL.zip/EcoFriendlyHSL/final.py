import requests
import json
import csv
import tkinter as tk
from tkinter import messagebox
from tkinter import *
from PIL import ImageTk, Image
import os
import sys

def resource_path(relative_path):
    try:
        base_path = sys._MEIPASS
    except Exception:
        base_path = os.path.abspath(".")
    return os.path.join(base_path, relative_path)

csv_file_path = resource_path('combined_data.csv')
image_file_path = resource_path('flamingo.png')

hsl_url = 'https://api.digitransit.fi/routing/v1/routers/hsl/index/graphql'


nominatim_url = "https://nominatim.openstreetmap.org/search"

# HSL API key
api_key = "" #PLEASE WRITE YOUR OWN HSL API KEY BETWEEN THE SIGNS ""
# GET JOURNEY PLANNER API AT (free subscription needed at API page): https://www.hsl.fi/en/hsl/open-data#journey-planner-ap-is

# Function to get latitude and longitude from location name
def geocode_location(location_name):
    params = {
        'q': location_name,
        'format': 'json',
        'limit': 1
    }
    headers = {
        'User-Agent': 'YourAppName/1.0 (eriko@ad.helsinki.fi)' 
    }
    response = requests.get(nominatim_url, params=params, headers=headers)

    if response.status_code == 200 and response.json():
        location = response.json()[0]
        lat = float(location['lat'])
        lon = float(location['lon'])
        return (lat, lon)
    else:
        print(f"Failed to geocode location: {response.status_code}")
        return None

# Function to read emissions data from CSV
def load_emissions_data(filename):
    emissions_data = {}
    with open(filename, mode='r', encoding='utf-8') as file:
        reader = csv.DictReader(file)
        for row in reader:
            route_short_name = row['route_short_name']
            avg_co2 = float(row['avg_co2_per_vehicle_per_km'])  # Assuming this is the emissions value
            emissions_data[route_short_name] = avg_co2
    return emissions_data

# Load emissions data from the CSV file
emissions_data = load_emissions_data('combined_data.csv')

# Function to get emissions based on route_id
def get_emissions(route_id):
    return emissions_data.get(route_id, None)

# GraphQL query to get route details including distance
def get_route(current_position, destination):
    query = """
    {
      plan(
        from: {lat: %f, lon: %f}
        to: {lat: %f, lon: %f}
        numItineraries: 3
      ) {
        itineraries {
          duration
          legs {
            mode
            startTime
            endTime
            distance
            from {
              name
            }
            to {
              name
            }
            trip {
              routeShortName
            }
          }
        }
      }
    }
    """ % (current_position[0], current_position[1], destination[0], destination[1])

    headers = {
        'Content-Type': 'application/json',
        'digitransit-subscription-key': api_key
    }

    response = requests.post(hsl_url, headers=headers, data=json.dumps({'query': query}))

    if response.status_code == 200:
        data = response.json()
        itineraries = data['data']['plan']['itineraries']
        results = []
        for itinerary in itineraries:
            total_emissions = 0  # To track the total emissions for the journey
            results.append(f"Itinerary Duration: {itinerary['duration'] / 60:.2f} minutes")
            for leg in itinerary['legs']:
                mode = leg['mode']
                start = leg['from']['name']
                end = leg['to']['name']
                route = leg['trip']['routeShortName'] if leg['trip'] else 'N/A'
                distance = leg['distance'] / 1000  # Distance is returned in meters, converting to km
                emissions_per_km = get_emissions(route)  # Get emissions for the route
                if emissions_per_km:
                    total_leg_emissions = emissions_per_km * distance
                    total_emissions += total_leg_emissions
                    results.append(f"  {mode}: {start} -> {end} (Route: {route}), Distance: {distance:.2f} km, Emissions/km: {emissions_per_km:.1f} g CO2/km, Emissions: {total_leg_emissions:.0f} g CO2")
                else:
                    results.append(f"  {mode}: {start} -> {end} (Route: {route}), Distance: {distance:.2f} km, Emissions: None g CO2")
            results.append(f" \n Total Emissions: {total_emissions:.0f} g CO2 \n \n")  # Print the total emissions for this itinerary
        return "\n".join(results)
    else:
        return f"Failed to retrieve data: {response.status_code}"

# Function to handle button click
def on_submit():
    current_location_name = current_location_entry.get()
    destination_name = destination_entry.get()

    # Get coordinates for the locations
    current_position = geocode_location(current_location_name)
    destination = geocode_location(destination_name)

    if current_position and destination:
        result = get_route(current_position, destination)
        messagebox.showinfo("Results", result)
    else:
        messagebox.showerror("Error", "Failed to geocode one or both locations.")

# Create the main window
root = tk.Tk()
root.title("Greener HSL")
root.geometry("600x500")
root.option_add("*Dialog.msg.wrapLength", "11i")
root.resizable(0,0)

# Load the image
images = Image.open("flamingo.png").resize((350,300))
images = ImageTk.PhotoImage(images)
lab = Label(root, image=images, bd=10, relief="groove")
lab.pack(pady=20)

# Create input fields
tk.Label(root, text="Current Location:").pack()
current_location_entry = tk.Entry(root, width=50)
current_location_entry.pack()

tk.Label(root, text="Destination:").pack()
destination_entry = tk.Entry(root, width=50)
destination_entry.pack()

# Create submit button
submit_button = tk.Button(root, text="Calculate Emissions!", command=on_submit)
submit_button.pack()

# Run the application
root.mainloop()
